from django.urls import path
from .views import (
    SignupView, LoginView, VerifyEmailView,
    UploadFileView, GenerateDownloadLinkView, DownloadFileView
)

urlpatterns = [
    path('signup/', SignupView.as_view(), name='signup'),
    path('login/', LoginView.as_view(), name='login'),
    path('verify-email/<int:user_id>/', VerifyEmailView.as_view(), name='verify-email'),
    path('upload-file/', UploadFileView.as_view(), name='upload-file'),
    path('generate-download-link/<int:file_id>/', GenerateDownloadLinkView.as_view(), name='generate-download-link'),
    path('download-file/<str:token>/', DownloadFileView.as_view(), name='download-file'),
]
