from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework.exceptions import NotFound, PermissionDenied
from django.core.signing import Signer, BadSignature
from django.core.mail import send_mail
from django.utils.timezone import now, timedelta
from django.conf import settings
from .models import File, SecureToken, User
from .serializers import UserSerializer, FileSerializer

signer = Signer()
import logging
from rest_framework.views import APIView
from rest_framework.response import Response
from .serializers import UserSerializer

# Set up logger
logger = logging.getLogger(__name__)
class SignupView(APIView):
    def post(self, request):
        # Log the incoming request
        logger.debug('Request received for signup')

        # Initialize the serializer with the request data
        serializer = UserSerializer(data=request.data)

        # Check if the data is valid
        if serializer.is_valid():
            logger.debug('Serializer valid')

            # Save the user if the data is valid
            user = serializer.save()

            # Return a success message
            return Response({'message': 'Signup successful'})
        
        # Log serializer errors if data is invalid
        logger.debug('Serializer errors: %s', serializer.errors)

        # Return the errors with a 400 status code
        return Response(serializer.errors, status=400)
from rest_framework.authtoken.models import Token
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from rest_framework.response import Response
from django.contrib.auth import authenticate
class LoginView(APIView):
    def post(self, request):
        # Extract credentials from the request data
        username = request.data.get('username')
        password = request.data.get('password')

        # Authenticate user
        user = authenticate(username=username, password=password)

        if user is not None:
            # Generate a token for the authenticated user
            token, created = Token.objects.get_or_create(user=user)
            return Response({'token': token.key})

        return Response({'error': 'Invalid credentials'}, status=400)


class VerifyEmailView(APIView):
    permission_classes = [AllowAny]

    def get(self, request, user_id):
        try:
            user = User.objects.get(id=user_id)
            user.is_active = True
            user.save()
            return Response({'message': 'Email verified successfully!'})
        except User.DoesNotExist:
            raise NotFound('User not found')


class UploadFileView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        if request.user.role != 'ops':
            raise PermissionDenied('Only Ops Users can upload files')

        serializer = FileSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(uploaded_by=request.user)
            return Response({'message': 'File uploaded successfully'})
        return Response(serializer.errors, status=400)


class GenerateDownloadLinkView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, file_id):
        if request.user.role != 'client':
            raise PermissionDenied('Only Client Users can access this')

        try:
            file = File.objects.get(id=file_id)
            # Create a secure token with expiration
            token = signer.sign(file.id)
            SecureToken.objects.create(
                file=file,
                token=token,
                created_at=now(),
                expires_at=now() + timedelta(hours=1)  # 1-hour expiry
            )
            return Response({'download-link': f'/download-file/{token}', 'message': 'success'})
        except File.DoesNotExist:
            raise NotFound('File not found')


class DownloadFileView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, token):
        try:
            original_id = signer.unsign(token)
            file = File.objects.get(id=original_id)

            # Check token validity
            secure_token = SecureToken.objects.get(token=token, file=file)
            if not secure_token.is_valid():
                return Response({'error': 'Token expired'}, status=403)

            # Serve the file for client users only
            if request.user.role != 'client':
                raise PermissionDenied('Unauthorized access')
            
            file_url = file.file.url  # Assuming `MEDIA_URL` is configured for serving files
            return Response({'file_url': file_url, 'message': 'File download ready'})
        except (BadSignature, File.DoesNotExist, SecureToken.DoesNotExist):
            return Response({'error': 'Invalid or expired token'}, status=400)
